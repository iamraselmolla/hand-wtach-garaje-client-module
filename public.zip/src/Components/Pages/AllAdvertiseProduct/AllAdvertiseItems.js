import React from 'react';

const AllAdvertiseItems = () => {
    return (
        <section>
            <div className="container">
                <div className="row">
                    
                </div>
            </div>
        </section>
    );
};

export default AllAdvertiseItems;