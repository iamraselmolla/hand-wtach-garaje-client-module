import React from 'react';

const AllBlockedUsers = () => {
    return (
        <div>
            
        </div>
    );
};

export default AllBlockedUsers;