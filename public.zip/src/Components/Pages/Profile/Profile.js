import React from 'react';

const Profile = () => {
    return (
        <div>
            
        </div>
    );
};

export default Profile;